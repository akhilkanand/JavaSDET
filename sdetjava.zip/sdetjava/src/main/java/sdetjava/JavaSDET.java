package sdetjava;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;

import org.json.simple.JSONObject;
class QueryParameter
{
	public static Arrays[][] itemsort;
	static int sort=0;
	static int flag=0;
	public static String name="";
	static String city="";
	static String id="";
	static String afieldname="";
	static int j=0;
	static Date date = new Date();
	static int row1=0;
	static int row=0;
	static int count=0;
	static int rowcount=0;
	static String season="";
	static String team1="";
	static String team2="";
	static String toss_winner="";
	static String toss_decision="";
	static String result="";
	static String dl_applied="";
	static String file="";
	static String baseQuery="";
	static String winner="";
	static int win_by_runs=0;
	static int win_by_wickets=0;
	static String player_of_match="";
	static String venue="";
	static String umpire1="";
	static String umpire2="";
	static String umpire3="";
	static String afterwhere="";
	public static String plogop="";
	static String orderby="";
	static String groupby="";
	static String aggfun="";
	static String order="";
	public static String[] lop= {"or","and","not"};
	static ArrayList<String> l = new ArrayList<String>(5); 
	static ArrayList<String> fields = new ArrayList<String>(10); 

	public static String getfile()
	{

		String f1[]=file.split(";");
		file=f1[0].toString();
		
		return file;
	}
	public static String getorderby() {
		return orderby;
	}
	public static String getPlogop() {
		return plogop;
	}
	public static ArrayList<String> getfields() {
	
		return fields;
	}
	public static String getgroupby() {
		return groupby;
	}
	public static String getafterwhere()
	{
		return afterwhere;
	}
	public static String getbaseQuery() {
		return baseQuery;
	}


}

class JavaSDET extends QueryParameter
{
	public static QueryParameter parseQuery(String queryString)
	{
		String[] qString=queryString.split(" ");
		for(int i=0;i<qString.length;i++)
		{
for(int j=0;j<lop.length;j++)
{
	if(qString[i].equalsIgnoreCase(lop[j]))
	{
		plogop=plogop+qString[i];
	}
}
		}
		for(int i=0;i<qString.length;i++)
		{
			if(qString[i].equals("from"))
			{
				for(int j=i+1;j<qString.length;j++)
				{
				if(qString[j].equals("where")||qString[j].equals("group"))
					break;
				file=file+qString[j];
				}				
			}
			else
			{
			if(qString[i].equals("where"))
			{
				for(int k=i+1;k<qString.length;k++)
				{
					if(qString[k].equals("order")&& qString[k+1].equals("by"))
					{
						for(int j=k+2;j<qString.length;j++)
						{
						orderby=orderby+qString[k+2];
						 k=j;
						}
						i=k;
					}
					else if(qString[k].equals("group")&& qString[k+1].equals("by"))
					{
						for(int j=k+2;j<qString.length;j++)
						{
						groupby=groupby+qString[k+2];
						 k=j;
						}
						i=k;
					}
					else{
						afterwhere=afterwhere+qString[k]+" ";
						i=k;
					}
				}	
			}
			else
			baseQuery=baseQuery+qString[i]+" ";
			
			}
			String[] field=baseQuery.split(" ");
	
			for(int j=1;j<field.length-1;j++)
			{
		fields.add(field[j]);
		
				String[] ag=field[j].split("\\(");
			
				for(int k=0;k<ag.length;k++)
				{
					
					String s[]=ag[k].split(",");
				
					for(int m=0;m<s.length;m++){
					
		if(s[m].equals("avg")||s[m].equals("max")||s[m].equals("min")||s[m].equalsIgnoreCase("count")||s[m].equalsIgnoreCase("sum"))
			{
				aggfun=aggfun+s[m]+" ";
			}
		else
		{
			String s1[]=s[0].split("\\)");
		l.add(s1[0]); 
		}
					}
				}
			}
		}	
		return new QueryParameter();
	} 
	public static void main(String[] args) throws ParseException, FileNotFoundException, IOException
	{
		JSONObject obj = new JSONObject();
		JSONObject obj1 = new JSONObject();
		
		String query="select count(city),sum(win_by_runs),min(season),max(win_by_wickets) from ipl.csv ";
		QueryParameter details = parseQuery(query);
		 String csvFile = "E:\\eclipse\\Corejava_SDET\\src\\"+getfile();
		 String line = "";
		 String line2 = "";
		 String[] arr = new String[l.size()]; 
		 String[] afun=aggfun.split(" ");
	        String cvsSplitBy = ",";
	        int sum=0,Min=0,Max=0,avg=0;
	        
	        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	            int f=1;
	        	while ((line2 = br.readLine()) != null) {
	        count++;     	
	        String[] c = line2.split(cvsSplitBy);
            if(f==1)
            {
            	for(int i=0;i<c.length;i++)
            		afieldname=afieldname+c[i]+",";
            }
            f++;
	    	
	        	}
	   }
	        String afiled[]=afieldname.split(",");
	        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
	        	Object[][] items= new String[count][20];
	        	int minArr[] = new int[count];
	        	int maxArr[] = new int[count];
	        	int intcount[] = new int[count];
	        	String Stringcount[] = new String[count];
	        	ArrayList<String> output=getfields();
	        	String[] array = output.toArray(new String[output.size()]);

	        	String where=getafterwhere();
	        	String a = array[0].toString();

	        	String[] a1=a.split(",");
	            while ((line = br.readLine()) != null) {
	           	if(row == 0) {
	                    row++;  
	                    continue;
	                }
	                String[] csvdata = line.split(cvsSplitBy);

 id=csvdata[0];
 season=csvdata[1];
 city=csvdata[2];
 Date date1=new SimpleDateFormat("dd-MM-yyyy").parse(csvdata[3]);
 team1=csvdata[4];
 team2=csvdata[5];
 toss_winner=csvdata[6];
 toss_decision=csvdata[7];
 result=csvdata[8];
 dl_applied=csvdata[9];
 winner=csvdata[10];
 win_by_runs=Integer.parseInt(csvdata[11]);
 win_by_wickets=Integer.parseInt(csvdata[12]);
 player_of_match=csvdata[13];
 venue=csvdata[14];
 umpire1=csvdata[15];
 umpire2=csvdata[16];
 umpire3=csvdata[17];
for (int i =0; i < l.size(); i++) 
    arr[i] = l.get(i); 

if(l.equals("")){
if(a1[0].equals("*"))
{ 
	
	if(where.equals(""))
	{
		for(int j=0;j<csvdata.length;j++)
			{
				String s=csvdata[j];
				items[row1][j]=s;			 
			}
	row1++;

	}
	else 
	{
		if(plogop.equals("and")||plogop.equals("or"))
		{

			String s= (String) Condition(where,a1,0,plogop,csvdata);
			if(s.equals(""))
				continue;
			else{
				String sp[]=s.split(",");
				for(int i=0;i<sp.length;i++)
				{
				items[rowcount][i]=	sp[i];
				}
				
				rowcount=rowcount+1;
				
			     }
		}
	else
	{
		
		String s = (String) Conditionwithwhere(where,a1,0,csvdata);
				
		if(s.equals(null))
			continue;
		else {
			String sp[]=s.split(",");
			for(int i=0;i<sp.length;i++)
			{
			items[rowcount][i]=	sp[i];

			}
			
			rowcount=rowcount+1;
		}
		     
	
 }
	}
	

}
else{
	
for(int i=0;i<a1.length;i++)
{
	
	if(where.equals(""))
	{
	
		
		String s=(String) print(a1[i]);
		 if(s !=null){
			
	items[rowcount][i]=	s;

	if(i==a1.length-1)
	rowcount=rowcount+1;
	
     }
		
	}
	else if(where!=null)
	{
	
		if(plogop.equals("and")||plogop.equals("or"))
				{
			String s=Condition(where,a1,i,plogop,csvdata);
			if(s.equals(""))
				continue;
			else{
										items[rowcount][i]=	s;
								if(i==a1.length-1)
									rowcount=rowcount+1;
			
				
			     }
				}
		else
		{

			 String s= Conditionwithwhere(where,a1,i,csvdata);
			 if(s !=null){
				
		items[rowcount][i]=	s;
		
		if(i==a1.length-1)
			rowcount=rowcount+1;
          }
	 }}}  
       }
}
else
	{
	if(afun.length==a1.length)
	{

	for(int i=0;i<arr.length;i++)
	{
		
		for(int j=0;j<afiled.length;j++)
		{
			
			if(afiled[j].equals(arr[i]))
			{
				
				
				if(afun[i].equalsIgnoreCase("Sum"))
						{
					sum=sum+Integer.parseInt(csvdata[j]);
					
						}
			
				else if(afun[i].equalsIgnoreCase("Min"))
				{
					minArr[rowcount]=Integer.parseInt(csvdata[j]);
					
				}
				else if(afun[i].equalsIgnoreCase("Max"))
				{
					maxArr[rowcount]=Integer.parseInt(csvdata[j]);
					
				}
				else if(afun[i].equalsIgnoreCase("count"))
				{
					if(csvdata[j] instanceof String)
				    Stringcount[rowcount]=csvdata[j];
					else
					intcount[rowcount]=Integer.parseInt(csvdata[j]);
					
				}
				else if(afun[i].equalsIgnoreCase("avg"))
				{
					avg=avg+Integer.parseInt(csvdata[j]);
					
				}
		
	
			}
		}
	}
	rowcount++;

Arrays.sort(minArr);
Min=minArr[0];
Arrays.sort(maxArr);
Max=maxArr[maxArr.length-1];
	}
	else
	{
		for(int i=0;i<a1.length;i++)
		{
			for(int j=0;j<afiled.length;j++)
			{
				if(arr[i].equals(afiled[j]))
				{
					items[rowcount][i]=csvdata[j];
					sort=i;
				}
			}
		
		}
		rowcount++;
	}

	}


       }
	            int[][] itemi=new int[arr.length][2];
	            Object[][] temp=new Object[items.length][2];
	         
	            if(afun.length !=a1.length){
	          for(int k=0;k<afun.length;k++)
	          {
	        	 
	        	 for(int j=0;j<rowcount;j++)
	        	 {
	        		 String us="";
	        		 int count1=0;
	        		
	        		 for(int i=j;i<rowcount;i++)
	        		 {
	        		
	        			 if(items[j][0].equals(items[i][0]))
	        			 {
	        				
	        				 if(afun[k].equalsIgnoreCase("sum")){
	        					 
	        				 count1=count1+Integer.parseInt((String) items[j][1]) ;
	        				 us=(String) items[i][0];
	        				
	        				 }
	        				 if(afun[k].equalsIgnoreCase("count")){
	        				
	        					 if(items[j][0].equals(items[j+1][0])){
	        						 
	        					 }
	        					 else
		        				 count1++ ;
		        				 us=(String) items[i][0];
		        				
		        				 }
	        			 }
	        		 }
	        		 temp[j][0]=us;
	        		 temp[j][1]=count1;
	   
	        	 }
	          }
	            }
	            avg=avg/count;
	            
	            if(a1.length==afun.length){
	        int   tcount = counttotal(Stringcount,intcount);
	        
	        for(int j=0;j<arr.length;j++)
	        {
	        	
	        	
				if(afun[j].equals("count"))
	        		itemi[j][0]=count;
	        	else if(afun[j].equals("avg"))
	        		itemi[j][0]=avg;
	        	else if(afun[j].equals("min"))
	        		itemi[j][0]=Min;
	        	else if(afun[j].equals("max"))
	        		itemi[j][0]=Max;
	        	else if(afun[j].equals("sum"))
	        		itemi[j][0]=sum;
	  
	        }
	            } 
	            
	            String[][] itemsort= new String[rowcount][a1.length];
	           
	            String s="";
	            if(itemi !=null && afun.length==a1.length)
	            {
	            	
	            	for(int i=0;i<arr.length;i++)
	            	{
	            		obj1.put(a1[i],itemi[i][0]);
	            	}
	            	
	            	
	            }
	            else if(afun.length!=a1.length)
	            {
	          
	            	for(int i=0;i<items.length-1;i++)
		            {
		            	
		   		            			itemsort[i][0]=(String) temp[i][0];
		            			itemsort[i][1]=String.valueOf(temp[i][1]);
		            		

		            	
		            }
		        	for(int  i=0;i<a1.length;i++)
		            {
		            	 if(orderby.equalsIgnoreCase(a1[i]))
		  	           { 
		          sort=i;
		  	           }
		            }
		            Arrays.sort(itemsort, new Comparator<Object>() {
	      		      public int compare(Object o1, Object o2) {
	      		    	  int s=sort;
	      		        String[] a = (String[])o1;
	      		        String[] b = (String[])o2;
	     
	      		        if(a.length == 0 && b.length == 0)
	      		          return 0;
	      		        if(a.length == 0 && b.length != 0)
	      		          return 1;
	      		        if(a.length != 0 && b.length == 0)
	      		          return -1;
	      		        return a[s].compareTo(b[s]);
	      		      }
	      		      public boolean equals(Object o) {
	      		        return this == o;
	      		      }
	      		    });
		           

	            	String ss = "";
	           String tep[]=new String[itemsort.length];
	           String tei[]=new String[itemsort.length];
	           int i;
	            	 for( i=itemsort.length-1,j=0;i>0;i--)
	                 { 
                      if(itemsort[i][0].equals(itemsort[i-1][0]) )
	            		 {
	            		}
	                else
	            		 {
	            			 j=j+1;
	            			 tep[j]=itemsort[i][0];
	            			 tei[j]=itemsort[i][1];
	            			
	     		           
	            			
	                 }
	            		 
	            		 

	            	}
	            	 tep[j+1]=itemsort[i][0];
	            		 tei[j+1]=itemsort[i][1];
 for( i=tep.length-1;i>0;i--)
	            		 
	                 { 
	 String sa=" ";
	if(tep[i]!=null)
	{
				 obj1.put(tep[i],sa);
	}
	       }

	            }
	            else if(orderby.equals("") )  
	                  {
	        	
	            for(int i=0,t=1;i<rowcount;i++,t++)
	            {
	            	
	            	String ob="";
	            	String name[]=null;
	            	String nm="";
	            	if(a1[0].equals("*")){
	            		
	            	for(int j=0;j<afiled.length;j++)
	            	{
	            		
	            		if(items[i][j]!=null)
	            		{
	            	 nm=nm+items[i][j]+",";
	        			
	            		}
                     }
	            	name=nm.split(","); 
	            	for(int k=0;k<name.length;k++)
	            	{
	            		obj.put(afiled[k],name[k]);
	            	}
	            ob=ob+obj;
	          
	               obj1.put(t,ob);
	            	
	            	}
	            	else{
	            		for(int j=0;j<a1.length;j++)
		            	{
		            		
		            		if(items[i][j]!=null)
		            		{
		            	
		      
		            	 nm=nm+items[i][j]+",";
		        			
		            		}
	                     }
	            		name=nm.split(","); 

		            	for(int k=0;k<name.length;k++)
		            	{
		            		obj.put(a1[k],name[k]);
		            	}
		            ob=ob+obj;
		          
		               obj1.put(t,ob);
	            	}
	            	 

	            }
	           
	        }
	        else if(orderby.equals("")&& a1.equals("")){
	        	String ss="";
	        	
	            for(int i=0,t=1;i<count;i++,t++)
	            {
	            	
	            	String name[]=null;
	            	String nm="";
	            	for(int j=0;j<a1.length;j++)
	            	{
	            	
	            		if(items[i][j]!=null)
	            		{
	            
	            			
	            	 nm=nm+items[i][j]+",";
	            	
	            	
	            		}
                     }
	            	 
	            	 name=nm.split(","); 
	            	 
	            	for(int k=0;k<name.length;k++)
	            	{
	            		
	            		obj.put(a1[k],name[k]);
	         
	            	}
	            	 ss=obj.toString();
	         
	         		  obj1.put(t,ss);
	          
	             
	            	
	            }
	          
	            
	        }
	        else 
	        {
	        	
	        	for(int i=0;i<items.length;i++)
	            {
	            	for(int j=0;j<a1.length;j++)
	            	{
	            		if(items[i][j]!=null)
	            		{
	          itemsort[i][j]=(String) items[i][j];
	            		}
	            
	            	}
	            }
	        	for(int  i=0;i<a1.length;i++)
	            {
	            	 if(orderby.equalsIgnoreCase(a1[i]))
	  	           { 
	          sort=i;
	  	           }
	            }
	            Arrays.sort(itemsort, new Comparator<Object>() {
      		      public int compare(Object o1, Object o2) {
      		    	  int s=sort;
      		        String[] a = (String[])o1;
      		        String[] b = (String[])o2;
     
      		        if(a.length == 0 && b.length == 0)
      		          return 0;
      		        if(a.length == 0 && b.length != 0)
      		          return 1;
      		        if(a.length != 0 && b.length == 0)
      		          return -1;
      		        return a[s].compareTo(b[s]);
      		      }
      		      public boolean equals(Object o) {
      		        return this == o;
      		      }
      		    });
	            
	            for(int i=0,t=1;i<itemsort.length;i++)
	            {
	            	String nm="",ob="";
					String[] name;
	            	for(int j=0;j<a1.length;j++)
	            	{
	            		if(itemsort[i][j].equals(""))
	            			continue;
	            		else
	            	           			
	            	 nm=nm+itemsort[i][j]+",";
	       
	            		name=nm.split(","); 
	          
		            	for(int k=0;k<name.length;k++)
		            	{
		            		obj.put(afiled[k],name[k]);
		            	}
	
	          }
	            	if(nm.equals(""))
	            		continue;
	            	else{
	            	ob=ob+obj;
			      obj1.put(t,ob); 	
			               t++;
	            	}
	            }
	        }
	     
	      
	        String s1[]=s.split(",,");
	        System.out.println(s1[0]);
	        try (FileWriter file = new FileWriter("d:\\newfile.json")) {
			 
				file.write(obj1.toJSONString());
				
				
				file.flush();

			}
			catch (IOException e) {
				e.printStackTrace();
			}

		System.out.println(obj1);    
	            
	      		
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	            
	      
	        
	        		
	        	
	}
	
	
	private static int counttotal(String[] stringcount, int[] intcount) {
		Integer[] tempi=new Integer[intcount.length];
		String temps[]=new String[stringcount.length];
	
		if(stringcount[0].equals(null))
		{
			
				for(int j=0,i=0;j<intcount.length;j++)
				{
			if(intcount[j]!=intcount[j+1])
			{
				tempi[i++]=intcount[j];
				count=i;
			}
				
		}
		}
		else{	
				for(int i=0,j=0;j<stringcount.length-1;j++)
				{
			if(stringcount[j].equalsIgnoreCase(stringcount[j+1]))
			{
				
			}
			else
			{
				temps[i++]=stringcount[j];
				count=i;
			}
			
				
		}
			
		}
		return count;
	}
	private static String Conditionwithwhere(String where,String[] a1,int i, String[] csvdata) throws IOException {
	String w[]=where.split(" ");
	Object value =swithchfun(w[0]);
	String output = "";
	
 if(value instanceof String)
{

	
 String s2=String.valueOf(value);  


if(w[1].equals("="))
{
	 
 if(s2.equalsIgnoreCase(w[2])){

	 if(a1[i].equals("*"))
		{
		
			output =  output(csvdata);
		}
	 else
	 {		
 output = (String) swithchfunnew(a1[i]);

	 }
}
}

}
 else if(value instanceof Integer){
	
 int integer1=Integer.parseInt(w[2]);
 int integer=(Integer)value;

if(w[1].equals("="))
{
	
if(integer==integer1){
	
 if(a1[i].equals("*"))
	{
	 
		output= output(csvdata);
		return output;
	}
 output=(String) print(a1[i]);
row++;
	} 
}
else if(w[1].equals("<"))
{

if(integer<integer1){
	System.out.println("Row:"+row);
	if(a1[i].equals("*"))
	{
		output =output(csvdata);
	}
 output=(String) print(a1[i]);
	row++;
		}
}
else if(w[1].equals(">"))
{
if(integer>integer1)
 {
	 System.out.println("Row:"+row);
	 if(a1[i].equals("*"))
		{
			output(csvdata);
		}
	print(a1[i]);
	 
		row++;
 }
}
 }

return  output;
 }	
		

	private static String Condition(String where,String[] a1,int i,String plogop,String[] csvdata) {
		String w[]=where.split(" ");

Object value =swithchfun(w[0]);
Object v2=swithchfun(w[4]);
String output="";
if(plogop.equals("and"))
		{
	
if(value instanceof String && v2 instanceof Integer)
{
	
String s2=String.valueOf(value);  
int integer1=Integer.parseInt(w[6]);
int integer=(Integer)v2;


if(w[1].equals("=") && w[5].equals("="))
{
	
if(s2.equalsIgnoreCase(w[2]) && integer==integer1)
{
	
	System.out.println(" ");
	if(a1[i].equals("*"))
	{
		output=output(csvdata);
		
	}
 print(a1[i]);
}
}
else if(s2.equalsIgnoreCase(w[2]) )
{
	if(w[5].equals("<"))
	{
 if(integer<integer1){
	 System.out.println("'"+row+"':");
	 if(a1[i].equals("*"))
		{
		 output=output(csvdata);
		}
				 output=(String) print(a1[i]);
				 row++;
		}
	}
	else if(w[5].equals(">"))
			{
 if(integer>integer1)
 {
	 if(a1[i].equals("*"))
		{
		 output=output(csvdata);
		}
	 output=(String) print(a1[i]); 
 }
			}
}

}

else if(value instanceof Integer && v2 instanceof String)
{
	
	String s2=String.valueOf(v2);  
	int integer1=Integer.parseInt(w[2]);
	int integer=(Integer)value;
	
	if(w[5].equals("=") && w[1].equals("="))
	{
		
	if(s2.equalsIgnoreCase(w[6]) && integer==integer1)
	{
		
		if(a1[i].equals("*"))
		{
			output=output(csvdata);
		}
		output=(String) print(a1[i]);
	}
	
	}
	else if(s2.equalsIgnoreCase(w[6]) )
	{
		
		if(w[1].equals("<"))
		{
			
	 if(integer<integer1){
		 System.out.println("'"+row+"':");
		 if(a1[i].equals("*"))
			{
			 output=output(csvdata);
			}
		 output= (String) print(a1[i]);
					 row++;
			}
		}
		else if(w[1].equals(">"))
				{
			
	 if(integer>integer1)
	 {
		 if(a1[i].equals("*"))
			{
			 output=output(csvdata);
			}
		 output= (String) print(a1[i]); 
	 }
				}
	}

}
	

		}		
else{
	if(value instanceof String || v2 instanceof Integer)
	{
		
	String s2=String.valueOf(value);  
	int integer1=Integer.parseInt(w[6]);
	int integer=(Integer)v2;


	if(w[1].equals("=") || w[5].equals("="))
	{
	if(s2.equalsIgnoreCase(w[2]) || integer==integer1)
	{
		if(a1[i].equals("*"))
		{
		
			output=output+output(csvdata);
		}
		output=(String) print(a1[i]);
	}
	}
	else if(s2.equalsIgnoreCase(w[2]) )
	{
		if(w[5].equals("<"))
		{
	 if(integer<integer1){
		 System.out.println("'"+row+"':");
		 if(a1[i].equals("*"))
			{
			 output=output(csvdata);
			}
		 output=(String) print(a1[i]);
					 row++;
			}
		}
		else if(w[5].equals(">"))
				{
	 if(integer>integer1)
	 {
		 if(a1[i].equals("*"))
			{
			 output=output(csvdata);
			}
		 output=(String) print(a1[i]); 
	 }
				}
	}

	}
	else if(value instanceof Integer || v2 instanceof String)
	{
		
		String s2=String.valueOf(v2);  
		int integer1=Integer.parseInt(w[2]);
		int integer=(Integer)value;
		
		if(w[1].equals("=") || w[5].equals("="))
		{
			
		if(s2.equalsIgnoreCase(w[6]) || integer==integer1)
		{
			
			if(a1[i].equals("*"))
			{
				output=output(csvdata);
			}
			output= (String) print(a1[i]);
		}
		
		}
		else if(s2.equalsIgnoreCase(w[6]) )
		{
			if(w[5].equals("<"))
			{
		 if(integer<integer1){
			 System.out.println("'"+row+"':");
			 if(a1[i].equals("*"))
				{
				 output=	output(csvdata);
				}
			 output= (String) print(a1[i]);
						 row++;
				}
			}
			else if(w[5].equals(">"))
					{
		 if(integer>integer1)
		 {
			 if(a1[i].equals("*"))
				{
				 output=output(csvdata);
				}
	
			 output= (String) print(a1[i]); 
			 
		 }
					}
		}

	}
}
return output;
		
	}
	private static String output(String csvdata[]) {
	
String output="";
for(int i=0;i<csvdata.length;i++)
{
	output=output+csvdata[i]+",";
}
	
		return output;
		}


	private static Object swithchfun(String string) {
	
			switch(string) {
			case "city" :
				
				return city;
	
		
			case "season" :
				int n=Integer.parseInt(season);
				return n;
			case "id" :
				int n1=Integer.parseInt(id);
				return n1;
			case "team1" :
				return team1;
			case "team2" :
				return team2;
			case "umpire1" :
				return umpire1;
			case "umpire2" :
				return umpire2;
			case "umpire3" :
				return umpire3;
			case "venue" :
				return venue;
			case "win_by_runs" :
				int n2=win_by_runs;
				return n2;
			case "win_by_wickets" :
				int n3=win_by_wickets;
				return n3;
				
			}
		
			return string;
			
		}
	private static Object swithchfunnew(String string) {
		
		switch(string) {
		case "city" :
			if(orderby.equals("city"))
			order=order+city+" ";
			return city;
		case "winner":
			return winner;
	
		case "season" :
			int n=Integer.parseInt(season);
			return  n;
		case "id" :
		
			return id;
		case "team1" :
			return team1;
		case "team2" :
			return team2;
		case "umpire1" :
			return umpire1;
		case "umpire2" :
			return umpire2;
		case "umpire3" :
			return umpire3;
		case "venue" :
			return venue;
		case "win_by_runs" :
			int n2=win_by_runs;
			return n2;
		case "win_by_wickets" :
			int n3=win_by_wickets;
			return n3;
			
		}
	
		return string;
		
	}
	private static Object print(String string) {
	
		switch(string) {
		case "id" :
		
			return id;
			
	
		case "city" :

		return city;
	  
		case "season" :
			return season;

		case "date" :
			return date;
		case "team1" :
			return team1;
		case "team2" :
			return team2;
		case "toss_winner" :
			return toss_winner;
		case "toss_decision" :
			return toss_decision;
		case "result" :
			return result;
		case "dl_applied" :
			return dl_applied;
		case "winner" :
			return winner;
		case "win_by_runs" :
			return winner;
		case "win_by_wickets" :
			return win_by_runs;
		case "player_of_match" :
			return player_of_match;
		case "venue" :
			return venue;
		case "umpire1" :
			return umpire1;
		case "umpire2" :
			return umpire2;
		case "umpire3" :
			return umpire3;
		}
		return string;
	}
		

	
}